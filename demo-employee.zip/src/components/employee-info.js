import React from 'react';

class EmployeeInfo extends React.Component {

    render() {
        return ;
    }
}